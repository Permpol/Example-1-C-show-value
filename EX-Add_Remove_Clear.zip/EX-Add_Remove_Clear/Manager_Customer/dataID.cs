﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Manager_Customer
{
    public class dataID
    {
        private string _numberID;

        public string numberID
        {
            get { return _numberID; }
            set { _numberID = value; }
        }
        
    }
}
