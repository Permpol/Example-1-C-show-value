﻿namespace Bank.Test2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.sb = new System.Windows.Forms.Button();
            this.Short = new System.Windows.Forms.Button();
            this.Integer = new System.Windows.Forms.Button();
            this.lo = new System.Windows.Forms.Button();
            this.by = new System.Windows.Forms.Button();
            this.us = new System.Windows.Forms.Button();
            this.ui = new System.Windows.Forms.Button();
            this.ul = new System.Windows.Forms.Button();
            this.fl = new System.Windows.Forms.Button();
            this.dou = new System.Windows.Forms.Button();
            this.de = new System.Windows.Forms.Button();
            this.ch = new System.Windows.Forms.Button();
            this.bo = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.Location = new System.Drawing.Point(176, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Show Value";
            // 
            // sb
            // 
            this.sb.Location = new System.Drawing.Point(40, 112);
            this.sb.Name = "sb";
            this.sb.Size = new System.Drawing.Size(75, 23);
            this.sb.TabIndex = 1;
            this.sb.Text = "Sbyte";
            this.sb.UseVisualStyleBackColor = true;
            this.sb.Click += new System.EventHandler(this.sb_Click);
            // 
            // Short
            // 
            this.Short.Location = new System.Drawing.Point(136, 112);
            this.Short.Name = "Short";
            this.Short.Size = new System.Drawing.Size(75, 23);
            this.Short.TabIndex = 2;
            this.Short.Text = "Short";
            this.Short.UseVisualStyleBackColor = true;
            this.Short.Click += new System.EventHandler(this.Short_Click);
            // 
            // Integer
            // 
            this.Integer.Location = new System.Drawing.Point(232, 112);
            this.Integer.Name = "Integer";
            this.Integer.Size = new System.Drawing.Size(75, 23);
            this.Integer.TabIndex = 3;
            this.Integer.Text = "Integer";
            this.Integer.UseVisualStyleBackColor = true;
            this.Integer.Click += new System.EventHandler(this.Integer_Click);
            // 
            // lo
            // 
            this.lo.Location = new System.Drawing.Point(328, 112);
            this.lo.Name = "lo";
            this.lo.Size = new System.Drawing.Size(75, 23);
            this.lo.TabIndex = 4;
            this.lo.Text = "long";
            this.lo.UseVisualStyleBackColor = true;
            this.lo.Click += new System.EventHandler(this.lo_Click);
            // 
            // by
            // 
            this.by.Location = new System.Drawing.Point(424, 112);
            this.by.Name = "by";
            this.by.Size = new System.Drawing.Size(75, 23);
            this.by.TabIndex = 5;
            this.by.Text = "byte";
            this.by.UseVisualStyleBackColor = true;
            this.by.Click += new System.EventHandler(this.by_Click);
            // 
            // us
            // 
            this.us.Location = new System.Drawing.Point(40, 160);
            this.us.Name = "us";
            this.us.Size = new System.Drawing.Size(75, 23);
            this.us.TabIndex = 6;
            this.us.Text = "UShort";
            this.us.UseVisualStyleBackColor = true;
            this.us.Click += new System.EventHandler(this.us_Click);
            // 
            // ui
            // 
            this.ui.Location = new System.Drawing.Point(136, 160);
            this.ui.Name = "ui";
            this.ui.Size = new System.Drawing.Size(75, 23);
            this.ui.TabIndex = 7;
            this.ui.Text = "UInteger";
            this.ui.UseVisualStyleBackColor = true;
            this.ui.Click += new System.EventHandler(this.ui_Click);
            // 
            // ul
            // 
            this.ul.Location = new System.Drawing.Point(232, 160);
            this.ul.Name = "ul";
            this.ul.Size = new System.Drawing.Size(75, 23);
            this.ul.TabIndex = 8;
            this.ul.Text = "ulong";
            this.ul.UseVisualStyleBackColor = true;
            this.ul.Click += new System.EventHandler(this.ul_Click);
            // 
            // fl
            // 
            this.fl.Location = new System.Drawing.Point(328, 160);
            this.fl.Name = "fl";
            this.fl.Size = new System.Drawing.Size(75, 23);
            this.fl.TabIndex = 9;
            this.fl.Text = "float";
            this.fl.UseVisualStyleBackColor = true;
            this.fl.Click += new System.EventHandler(this.fl_Click);
            // 
            // dou
            // 
            this.dou.Location = new System.Drawing.Point(424, 160);
            this.dou.Name = "dou";
            this.dou.Size = new System.Drawing.Size(75, 23);
            this.dou.TabIndex = 10;
            this.dou.Text = "double";
            this.dou.UseVisualStyleBackColor = true;
            this.dou.Click += new System.EventHandler(this.dou_Click);
            // 
            // de
            // 
            this.de.Location = new System.Drawing.Point(136, 208);
            this.de.Name = "de";
            this.de.Size = new System.Drawing.Size(75, 23);
            this.de.TabIndex = 11;
            this.de.Text = "decimal";
            this.de.UseVisualStyleBackColor = true;
            this.de.Click += new System.EventHandler(this.de_Click);
            // 
            // ch
            // 
            this.ch.Location = new System.Drawing.Point(232, 208);
            this.ch.Name = "ch";
            this.ch.Size = new System.Drawing.Size(75, 23);
            this.ch.TabIndex = 12;
            this.ch.Text = "Char";
            this.ch.UseVisualStyleBackColor = true;
            this.ch.Click += new System.EventHandler(this.ch_Click);
            // 
            // bo
            // 
            this.bo.Location = new System.Drawing.Point(336, 208);
            this.bo.Name = "bo";
            this.bo.Size = new System.Drawing.Size(75, 23);
            this.bo.TabIndex = 13;
            this.bo.Text = "Boolean";
            this.bo.UseVisualStyleBackColor = true;
            this.bo.Click += new System.EventHandler(this.bo_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "กรุณเลือกค่าที่ต้องการดู";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 337);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bo);
            this.Controls.Add(this.ch);
            this.Controls.Add(this.de);
            this.Controls.Add(this.dou);
            this.Controls.Add(this.fl);
            this.Controls.Add(this.ul);
            this.Controls.Add(this.ui);
            this.Controls.Add(this.us);
            this.Controls.Add(this.by);
            this.Controls.Add(this.lo);
            this.Controls.Add(this.Integer);
            this.Controls.Add(this.Short);
            this.Controls.Add(this.sb);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button sb;
        private System.Windows.Forms.Button Short;
        private System.Windows.Forms.Button Integer;
        private System.Windows.Forms.Button lo;
        private System.Windows.Forms.Button by;
        private System.Windows.Forms.Button us;
        private System.Windows.Forms.Button ui;
        private System.Windows.Forms.Button ul;
        private System.Windows.Forms.Button fl;
        private System.Windows.Forms.Button dou;
        private System.Windows.Forms.Button de;
        private System.Windows.Forms.Button ch;
        private System.Windows.Forms.Button bo;
        private System.Windows.Forms.Label label2;
    }
}

